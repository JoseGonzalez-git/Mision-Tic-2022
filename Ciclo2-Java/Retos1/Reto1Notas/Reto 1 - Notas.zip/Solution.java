public class Solution{
    //ESTA CLASE NO TIENE MAIN
    
    
    public static double[] reporte(double[] listaNotas) {
        //EN ESTE ESPACIO PONER SU LÓGICA
        
        
        
        
        
    }
}